import ClusterType
import Common

C = ClusterType.ClusterData()

C.ClassifyEntry("EZ")
C.ClassifyEntry("WZ")
C.ClassifyEntry("NZ")
C.ClassifyEntry("SZ")
C.ClassifyEntry("CZ")
